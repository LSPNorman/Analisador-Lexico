/**
 * 
 */
/**
 * @author LSPNorman
 *
 */
module analisadorLexico {
	requires java.desktop;
}